<?php include 'header.php' ?>
<!-- Vendors CSS -->
<link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
<link rel="stylesheet" href="assets/vendor/libs/typeahead-js/typeahead.css" />
<link rel="stylesheet" href="assets/vendor/libs/datatables-bs5/datatables.bootstrap5.css" />
<link rel="stylesheet" href="assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css" />
<link rel="stylesheet" href="assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css" />
<link rel="stylesheet" href="assets/vendor/libs/select2/select2.css" />
<link rel="stylesheet" href="assets/vendor/libs/@form-validation/form-validation.css" />

<div class="container-xxl flex-grow-1" style="padding: 0px 10px;">
    <div class="card mb-2">
        <div class="row p-2">
            <div class="col-md-8">
                <h6 class="card-header"><i class="ri-building-line"></i> District Event Details</h6>
            </div>
            <?php if(get_permission('district_event', 'is_add')){ ?>
            <div class="col-md-4 text-end">
                <button type="button" class="btn btn-xs btn-primary rounded-pill add_btn">
                    <i class="ri-file-add-fill"></i> Add New
                </button>
            </div>
            <?php } ?>
        </div>
    </div>
    <div class="card">
        <div class="table-responsive text-nowrap">
            <table id="clubTable" class="table" style="width: 100%;"> 
                <thead>
                    <tr>
                        <th>Sl.No</th>
                        <th>Registration Start Date</th>
                        <th>Registration End Date</th>
                        <!--<th>Event Level Type</th>-->
                        <th>Event Name</th>
                        <th>State</th>
                        <th>District</th>
                        <th>Event Fees</th>
                        <!--<th>Event Image</th>-->
                        <th>Event Date </th>
                        <th>Event Description</th>
                        <th>Event Remarks</th>
                        <th>Status</th>
                        <th>Title of Championship</th>
                        <th>Association Name</th>
                        <th>Registration Number</th>
                        <th>Date</th>
                        <th>Venue</th>
                        <?php if(get_permission('district_event', 'is_edit') ||  get_permission('district_event', 'is_delete')){ ?>
                        <th>Actions</th>
                        <?php } ?>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<!--delete Modal-->
<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Are you sure you want to delete this Events?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php' ?>
<!-- Vendors JS -->
<script src="assets/vendor/libs/jquery/jquery.js"></script>
<script src="assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<script src="assets/vendor/libs/select2/select2.js"></script>
<script>
$(document).ready(function () {
    
$('.add_btn').on('click', function() {
    window.location.href = 'district-events.php';
});
    
    const table = $('#clubTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: 'api/d-events/read.php',
            type: 'GET'
        },
       columns: [
    { data: null, render: (data, type, row, meta) => meta.row + 1 },
    { 
        data: 'reg_start_date',
        render: (data) => {
            if (!data) return ''; 
            const date = new Date(data);
            const formattedDate = date.toLocaleDateString('en-GB').split('/').reverse().join('-'); // Converts to DD-MM-YYYY
            const formattedTime = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }).replace(':', '.'); // hh.mmAM/PM
            return `${formattedDate}-${formattedTime}`;
        }
    },
    { 
        data: 'reg_end_date',
        render: (data) => {
            if (!data) return ''; 
            const date = new Date(data);
            const formattedDate = date.toLocaleDateString('en-GB').split('/').reverse().join('-'); // Converts to DD-MM-YYYY
            const formattedTime = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }).replace(':', '.'); // hh.mmAM/PM
            return `${formattedDate}-${formattedTime}`;
        }
    },
    
    { data: 'event_name' },
    { data: 'state_name' },
    { data: 'district_name' },
    { data: 'event_fees' },
    { data: 'event_date' },
    { data: 'event_description' },
    { data: 'event_remarks' },
    { data: 'status' },
    { data: 'title_of_championship' },
    { data: 'association_name' },
    { data: 'reg_no' },
    { data: 'date' },
    { data: 'venue' },
    <?php if(get_permission('district_event', 'is_edit') ||  get_permission('district_event', 'is_delete')){ ?>
    {
        data: null,
        render: (data) => `<?php if(get_permission('district_event', 'is_edit')){ ?>
        <a class="btn btn-warning btn-xs" href="events-report.php?event_id=${data.id}"><i class="ri-edit-box-fill"></i> View Event Register List</a>
            <button class="btn btn-warning btn-xs" onclick="editClub(${data.id})"><i class="ri-edit-box-fill"></i> Edit</button>
            <?php }  if(get_permission('district_event', 'is_delete')){ ?>
            <button class="btn btn-danger btn-xs" onclick="deleteClub(${data.id})"><i class="ri-chat-delete-fill"></i> Delete</button>
         <?php } ?>  `
    }
    <?php } ?> 
]

    });

    $('#branchForm').on('submit', function (e) {
        e.preventDefault();
        if (this.checkValidity()) {
            submitBranchForm();
        } else {
            this.classList.add('was-validated');
        }
    });
});


function editClub(id) {
   window.location.href = 'district-events.php?id='+id;
}

var deleteId = null; // Store the ID of the product to be deleted

function deleteClub(id) {
    deleteId = id;
    $('#deleteModal').modal('show'); // Show the modal
}


$('#confirmDelete').click(function () {
    if (deleteId) {
        $.ajax({
            url: `api/d-events/delete.php`,
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ id: deleteId }),
            dataType: 'json', // Ensure the response is treated as JSON
            success: function (response) {
                console.log(response);
                $('#deleteModal').modal('hide'); // Hide modal on success
                if (response.status === 'success') {
                    showtoastt(response.message, 'success');
                    $('#clubTable').DataTable().ajax.reload();
                } else {
                    showtoastt(response.message, 'red');
                    $('#clubTable').DataTable().ajax.reload();
                }
            },
            error: function (jqXHR) {
                //$('#clubTable').modal('hide');
                $('#deleteModal').modal('hide'); // Hide modal on success
                let errorMessage = 'Something went wrong...';
                $('#clubTable').DataTable().ajax.reload();
                if (jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    errorMessage = jqXHR.responseJSON.message;
                }
                showtoastt(errorMessage, 'red');
            }
        });
    }
});
</script>
