<?php
header('Content-Type: application/json');
include '../../config/config.php'; // Adjust this path if necessary

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo->beginTransaction(); // Start transaction

        $event_id   = intval($_POST['event_id']);
        $level_id   = intval($_POST['level_id']);
        $all_memberId  = isset($_POST['all_memberId']) ? $_POST['all_memberId'] : [];
        $selected   = isset($_POST['selected_memberId']) ? $_POST['selected_memberId'] : [];
        $absent     = isset($_POST['absent_memberId']) ? $_POST['absent_memberId'] : [];
        $first      = intval($_POST['first_place_memberId'] ?? 0);
        $second     = intval($_POST['second_place_memberId'] ?? 0);
        $third      = intval($_POST['third_place_memberId'] ?? 0);

        // Combine all IDs that will be updated in any way
        $ids_to_reset = array_unique(array_merge($selected, $absent,$all_memberId, [$first, $second, $third]));
        $ids_to_reset = array_filter($ids_to_reset); // remove empty / zero

        if (!empty($ids_to_reset)) {
            // Reset only the relevant skater IDs
            $reset_sql = "
                UPDATE tbl_event_registration
                SET result = 0, is_present = 0, prize_announcement_place = 0
                WHERE id IN (" . implode(',', array_map('intval', $ids_to_reset)) . ")
            ";
            $stmt = $pdo->prepare($reset_sql);
            $stmt->execute();
        }

        // Update Selected Members (result = 1, is_present = 1)
        if (!empty($selected)) {
            $sql = "
                UPDATE tbl_event_registration
                SET result = 1, is_present = 1
                WHERE id IN (" . implode(',', array_map('intval', $selected)) . ")
            ";
            $pdo->query($sql)->execute();
        }

        // Update Absent Members (is_present = 0 but keep result if needed)
        if (!empty($absent)) {
            $sql = "
                UPDATE tbl_event_registration
                SET is_present = 0
                WHERE id IN (" . implode(',', array_map('intval', $absent)) . ")
            ";
            $pdo->query($sql)->execute();
        }

        // Update Prize Places
        if ($first > 0) {
            $pdo->prepare("
                UPDATE tbl_event_registration
                SET prize_announcement_place = 1
                WHERE id = :id
            ")->execute([':id' => $first]);
        }

        if ($second > 0) {
            $pdo->prepare("
                UPDATE tbl_event_registration
                SET prize_announcement_place = 2
                WHERE id = :id
            ")->execute([':id' => $second]);
        }

        if ($third > 0) {
            $pdo->prepare("
                UPDATE tbl_event_registration
                SET prize_announcement_place = 3
                WHERE id = :id
            ")->execute([':id' => $third]);
        }

        $pdo->commit(); // Commit if all queries succeed
        echo json_encode(['success' => true, 'message' => 'Members updated successfully']);

    } catch (Exception $e) {
        $pdo->rollBack(); // Rollback on error
        error_log($e->getMessage());
        echo json_encode(['error' => 'Update failed: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
}
