<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Certificate of Merit / Participation</title>
  <style>
    @font-face {
      font-family: 'Montserrat-Bold';
      src: url('Montserrat-Bold.ttf') format('truetype');
    }
    @font-face {
      font-family: 'Montserrat-SemiBold';
      src: url('Montserrat-SemiBold.ttf') format('truetype');
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: 'Montserrat-SemiBold', sans-serif;
      background-color: #f5f5f5;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
    }
    
    .certificate {
      position: relative;
      width: 297mm;   /* A4 landscape */
      height: 210mm;
      margin: auto;
      background: url('template.jpeg') no-repeat center center;
      background-size: cover;
      border: 15px solid #d4af37; /* Golden border */
      box-sizing: border-box;
      box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
    }

    /* Top header section */
    .header-text {
      position: absolute;
      top: 30mm;
      left: 50%;
      transform: translateX(-50%);
      text-align: center;
      font-family: 'Montserrat-SemiBold';
      font-size: 12pt;
      line-height: 1.0;
      width: 90%;
    }

    .top-logo {
      max-width: 90mm;
      position: absolute;
      top: 8mm;
      right: 15mm;
      height: 10mm;
    }

    /* Title (Certificate Header Image) */
    .title-img {
      position: absolute;
      top: 60mm;
      left: 50%;
      transform: translateX(-50%);
      width: 140mm;
      height: 25mm;
    }

    .subtitle {
      position: absolute;
      top: 75mm;
      left: 50%;
      transform: translateX(-50%);
      font-size: 14pt;
      font-family: 'Montserrat-Bold';
      text-align: center;
    }

    /* Participant Details */
    .content-area {
      position: absolute;
      top: 90mm;
      left: 50%;
      transform: translateX(-50%);
      width: 85%;
      text-align: justify;
      font-size: 12pt;
      font-family: 'Montserrat-SemiBold';
      line-height: 1.7;
    }

    .dotted-line {
      display: inline-block;
      border-bottom: 1px dotted #000;
      min-width: 50mm;
      vertical-align: bottom;
    }
    
    .long-dotted-line {
      display: inline-block;
      border-bottom: 1px dotted #000;
      min-width: 100mm;
      vertical-align: bottom;
    }

    /* Event Result Section */
    .results {
      margin-top: 8mm;
      margin-bottom: 20mm;
      font-size: 12pt;
      line-height: 1.6;
      text-align: center;
    }

    .results strong {
      font-family: 'Montserrat-Bold';
    }

    /* Signatures */
  /* Signatures */
.signatures {
  margin-top: 8mm;
  position: absolute;
  bottom: 10mm;
  width: 100%;
  display: flex;
  justify-content: space-between; /* Changed from space-around */
  text-align: center;
  font-size: 11pt;
  font-family: 'Montserrat-SemiBold';
  padding: 0 40px; /* Add padding to keep away from edges */
  box-sizing: border-box;
}

.signature-left {
  text-align: center;
  margin-left: 40px;
}

.signature-right {
  text-align: center;
  margin-right: 40px;
}

.sign-line {
  border-top: 1px solid #000;
  width: 150px;
  margin: 5px 0;
}

    /*.sign-line {*/
    /*  border-top: 1px solid #000;*/
    /*  width: 60mm;*/
    /*  margin: 0 auto 5mm auto;*/
    /*}*/

    /* Footer logos */
    .footer-logos {
    max-width: 20mm;
      position: absolute;
      bottom: 2mm;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      justify-content: center;
      gap: 5mm;
      width: 80%;
    }
    
    .footer-logo {
      height: 15mm;
    }
    
    .print-btn {
      margin-top: 20px;
      padding: 12px 25px;
      background: #d4af37;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-family: 'Montserrat-SemiBold';
      font-size: 16px;
      transition: background 0.3s;
    }
    
    .print-btn:hover {
      background: #b8941f;
    }
    
    @media print {
      body {
        background: none;
        padding: 0;
      }
      
      .print-btn {
        display: none;
      }
    }
  </style>
</head>
<body>
  <div class="certificate">
    <!-- Header -->
    <div class="header-text">
      <!--National Sports Promotion Organization =<br>-->
      <!--(NSPO) Recognised By 2 Ketoi™<br>-->
      <h1>MADURAI SPEED SKATING ASSOCIATION</h1><br>
      AFFILIATED TO TAMILNADU SPEED SKATING ASSOCIATION (TNSSA)<br>
      RECOGNIZED BY SPEED SKATING FEDERATION OF INDIA (SSFI)<br>
      NMSSA IN ASSOCIATION WITH STAIRS FOUNDATION
    </div>
    <img src="top-logo-removebg-preview.png" alt="Top Logo" class="top-logo">

    <!-- Title -->
    <img src="certificate_header_name-removebg-preview.png" alt="Certificate Title" class="title-img">
    <!--<div class="subtitle">Certificate of Merit / Participation</div>-->

    <!-- Content -->
    <div class="content-area">
      Member Id : <span ></span><br><br>
      This is to certify that <span >...............................................................................................................................................</span>in the Age Category<br>
      <span >.......................................................</span> has participated in the <span>................................................................................................................................</span><br>
      held on <span >.....................................................</span> at <span >.........................................................................................................................................................</span><br>
      representing <span >...............................................................................................</span> club <span >..................................................................................................</span><br>
      district <span >............................................................................................................</span> and ranked as under<br>
      
      <div class="results">
        <strong>SKATE CATEGORY :</strong> QUAD<br>
        200M – GOLD &nbsp;&nbsp; 400M – SILVER &nbsp;&nbsp; ELIMINATION – BRONZE<br>
        RELAY – GOLD / SILVER / BRONZE / Participated / NIL
      </div>
    </div>

    <!-- Signatures -->
<div class="signatures">
  <div class="signature-left">
    <div class="sign-line"></div>
    S. MURUGANANDHAM<br>
    President
    
  </div>
  <div class="signature-right">
    <div class="sign-line"></div>
    M. GOWTHAM<br>
    General Secretary
    
  </div>


    <!-- Footer Logos -->
    <div class="footer-logos">
      <img src="bottom-logo1.jpeg" alt="Bottom Logo 1" class="footer-logo">
      <img src="bottom-logo2.jpeg" alt="Bottom Logo 2" class="footer-logo">
      <img src="bottom-logo3.jpeg" alt="Bottom Logo 3" class="footer-logo">
      <img src="bottom-logo4.jpeg" alt="Bottom Logo 3" class="footer-logo">
    </div>
    </div>
  </div>

</body>
</html>